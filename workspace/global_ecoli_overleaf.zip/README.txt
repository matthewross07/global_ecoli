Earth's Future manuscript -- Overleaf project
Main file: paper.tex  (\documentclass{agujournal2019})
Bibliography: refs.bib (AGU apacite style; Overleaf provides apacite)
Figures: 5 PNGs referenced by filename.
Included class/style: agujournal2019.cls, trackchanges.sty.
Standard packages (apacite, lineno, soul, url) come from Overleaf's TeX Live.
Build on Overleaf: New Project -> Upload Project -> this zip; it auto-detects paper.tex.
