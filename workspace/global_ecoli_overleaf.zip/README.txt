Earth's Future manuscript — Overleaf project
Main file: paper.tex  (\documentclass{agujournal2019})
Bibliography: refs.bib (AGU apacite style; Overleaf provides apacite)
Figures: 5 PNGs referenced by filename.
Included class/style: agujournal2019.cls, trackchanges.sty.
Standard packages (apacite, lineno, soul, url) are provided by Overleaf's TeX Live.
To build on Overleaf: upload this zip ("New Project -> Upload Project"); it auto-detects paper.tex.
